# New Store Location Recommendation

## Executive Summary
Based on comprehensive analysis of store revenue patterns, geospatial distribution, and sensitivity testing, we recommend establishing a new store in the area west of St. Robert, Missouri at the following coordinates:

**Primary Recommendation: Optimal Location 3**
- **Latitude**: 38.275039
- **Longitude**: -92.751795
- **Combined Score**: 0.5159 (highest of all potential locations)
- **Nearest Existing Store**: St. Robert (Distance: 0.7621 degrees)

This location offers the optimal balance of revenue potential and market isolation, positioned to capture underserved areas while benefiting from regional revenue patterns.

## Alternative Locations
Two additional high-potential locations were identified:

**Alternative 1: Optimal Location 2**
- **Latitude**: 38.110260
- **Longitude**: -92.943106
- **Combined Score**: 0.5154
- **Nearest Existing Store**: St. Robert (Distance: 0.8533 degrees)

**Alternative 2: Optimal Location 1**
- **Latitude**: 37.978437
- **Longitude**: -92.990934
- **Combined Score**: 0.5126
- **Nearest Existing Store**: St. Robert (Distance: 0.8649 degrees)

## Analysis Methodology
Our recommendation is based on a multi-faceted analysis approach:

1. **Revenue Pattern Analysis**: Identified highest-performing stores and days of the week
2. **Geospatial Analysis**: Mapped store distribution and calculated isolation scores
3. **Two-Way Sensitivity Test**: Analyzed how latitude and longitude affect revenue potential
4. **Combined Scoring**: Balanced revenue potential with market isolation

## Key Findings

### Revenue Patterns
- Columbia is the highest revenue store (,892,823), followed by Springfield Battlefield (,951,247)
- Saturday is consistently the highest revenue day across all stores
- The highest single store-day combination is Columbia on Saturday (,452,466)
- Friday is the second-highest revenue day across stores

### Geospatial Insights
- Stores with high isolation scores (revenue potential in less saturated areas):
  1. Springfield Battlefield (Isolation Score: 20.38)
  2. Columbia (Isolation Score: 14.90)
  3. Ozark (Isolation Score: 13.44)
- The average distance between existing stores is 1.47 degrees
- The area west of St. Robert represents an underserved region with high revenue potential

### Operational Recommendations
Based on revenue patterns across existing stores, we recommend:

1. **Prioritize Weekend Operations**: Ensure full staffing and inventory for Saturday and Friday
2. **Location-Specific Strategy**: The recommended location should follow the operational model of high-performing stores like Columbia
3. **Market Testing**: Consider pop-up operations in the recommended area before full store development

## Conclusion
The recommended location west of St. Robert offers the optimal balance of revenue potential and market isolation. This area is sufficiently distant from existing stores to avoid cannibalization while benefiting from regional revenue patterns observed in our analysis. The location's high combined score indicates strong potential for success based on both revenue projections and strategic positioning.

We recommend proceeding with site evaluation and market testing in this area, with particular attention to weekend operations which drive the highest revenue across our store network.
